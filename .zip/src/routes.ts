import type { FastifyInstance } from "fastify";

import { checkDatabaseConnection } from "./database";
import { authRoutes } from "./modules/auth/routes";
import { verificationRoutes } from "./modules/auth/verification-routes";

export async function registerRoutes(app: FastifyInstance) {
    await app.register(authRoutes, { prefix: "/auth" });
    await app.register(verificationRoutes, { prefix: "/auth" });

    app.get("/health", async (_request, reply) => {
        try {
            await checkDatabaseConnection();

            return {
                status: "ok",
                service: "miyor-api",
                database: "connected",
            };
        } catch (error) {
            app.log.error(error);

            return reply.status(503).send({
                status: "error",
                service: "miyor-api",
                database: "disconnected",
            });
        }
    });
}
