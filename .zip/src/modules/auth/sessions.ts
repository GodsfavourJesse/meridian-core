import { createHash, randomBytes } from "node:crypto";

import { and, eq, gt, isNull } from "drizzle-orm";
import { env } from "../../config/env";
import { db } from "../../database";
import { sessions } from "../../database/schema";


export const SESSION_COOKIE_NAME = "miyor_session";

const SESSION_DURATION_MS = 1000 * 60 * 60 * 24 * 30;

export function createSessionToken() {
    return randomBytes(32).toString("hex");
}

export function hashSessionToken(token: string) {
    return createHash("sha256")
        .update(`${env.SESSION_SECRET}:${token}`)
        .digest("hex");
}

export function getSessionExpiration() {
    return new Date(Date.now() + SESSION_DURATION_MS);
}

export async function createSession(userId: string) {
    const token = createSessionToken();
    const tokenHash = hashSessionToken(token);
    const expiresAt = getSessionExpiration();

    const [session] = await db
        .insert(sessions)
        .values({
            userId,
            tokenHash,
            expiresAt,
        })
        .returning({
            id: sessions.id,
            userId: sessions.userId,
            expiresAt: sessions.expiresAt,
        });

    if (!session) {
        throw new Error("Failed to create session");
    }

    return {
        token,
        ...session,
    };
}

export async function getSession(token: string) {
    const tokenHash = hashSessionToken(token);

    const [session] = await db
        .select({
            id: sessions.id,
            userId: sessions.userId,
            expiresAt: sessions.expiresAt,
        })
        .from(sessions)
        .where(
            and(
                eq(sessions.tokenHash, tokenHash),
                isNull(sessions.revokedAt),
                gt(sessions.expiresAt, new Date()),
            ),
        )
        .limit(1);

    return session ?? null;
}

export async function revokeSession(token: string) {
    const tokenHash = hashSessionToken(token);

    await db
        .update(sessions)
        .set({
            revokedAt: new Date(),
        })
        .where(eq(sessions.tokenHash, tokenHash));
}