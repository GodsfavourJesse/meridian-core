import nodemailer from "nodemailer";

import { env } from "../../config/env";

function getTransporter() {
    if (
        !env.SMTP_HOST ||
        !env.SMTP_USER ||
        !env.SMTP_PASSWORD
    ) {
        return null;
    }

    return nodemailer.createTransport({
        host: env.SMTP_HOST,
        port: env.SMTP_PORT,
        secure: env.SMTP_PORT === 465,
        auth: {
            user: env.SMTP_USER,
            pass: env.SMTP_PASSWORD,
        },
    });
}

export async function sendVerificationEmail({
    email,
    name,
    token,
}: {
    email: string;
    name: string;
    token: string;
}) {
    const verificationUrl =
        `${env.APP_URL}/auth/verify-email?token=${encodeURIComponent(token)}`;

    const transporter = getTransporter();

    if (!transporter) {
        if (env.NODE_ENV === "production") {
            throw new Error(
                "SMTP is not configured",
            );
        }

        console.info(
            `[Miyor] Email verification URL for ${email}: ${verificationUrl}`,
        );

        return;
    }

    await transporter.sendMail({
        from:
            env.SMTP_FROM ??
            env.SMTP_USER,

        to: email,

        subject: "Verify your Miyor email address",

        text: [
            `Hi ${name},`,
            "",
            "Welcome to Miyor.",
            "",
            "Verify your email address using the link below:",
            verificationUrl,
            "",
            "This link expires in 30 minutes.",
            "",
            "If you did not create a Miyor account, you can ignore this email.",
        ].join("\n"),

        html: `
            <div style="font-family: Arial, sans-serif; line-height: 1.6;">
                <h2>Welcome to Miyor</h2>

                <p>Hi ${name},</p>

                <p>
                    Verify your email address to finish setting up
                    your Miyor account.
                </p>

                <p>
                    <a
                        href="${verificationUrl}"
                        style="
                            display:inline-block;
                            padding:12px 20px;
                            background:#020617;
                            color:#ffffff;
                            text-decoration:none;
                            border-radius:8px;
                        "
                    >
                        Verify email
                    </a>
                </p>

                <p style="color:#64748b;">
                    This link expires in 30 minutes.
                </p>
            </div>
        `,
    });
}