import { buildApp } from "./app";
import { env } from "./config/env";

const app = buildApp();

async function start() {
    try {
        await app.listen({
            port: env.PORT,
            host: "0.0.0.0",
        });

        app.log.info(
            `🚀 Miyor API running on ${env.API_URL}`,
        );
    } catch (error) {
        app.log.error(error);
        process.exit(1);
    }
}

async function shutdown(signal: string) {
    app.log.info(`${signal} received. Shutting down...`);

    try {
        await app.close();
        process.exit(0);
    } catch (error) {
        app.log.error(error);
        process.exit(1);
    }
}

process.once("SIGINT", () => {
    void shutdown("SIGINT");
});

process.once("SIGTERM", () => {
    void shutdown("SIGTERM");
});

void start();
