import Fastify from "fastify";
import cors from "@fastify/cors";
import cookie from "@fastify/cookie";

import { env } from "./config/env";
import { checkDatabaseConnection } from "./database";

import { authRoutes } from "./auth/routes";

export function buildApp() {
    const app = Fastify({
        logger: {
            level: env.NODE_ENV === "development" ? "info" : "warn",
        },
    });

    app.register(cors, {
        origin: env.APP_URL,
        credentials: true,
    });

    app.register(cookie);

    app.register(authRoutes);

    app.get("/health", async (_request, reply) => {
        try {
            await checkDatabaseConnection();

            return {
                status: "ok",
                service: "miyor-api",
                database: "connected",
            };
        } catch (error) {
            app.log.error(error);

            return reply.status(503).send({
                status: "error",
                service: "miyor-api",
                database: "disconnected",
            });
        }
    });

    app.setErrorHandler((error, request, reply) => {
        request.log.error(error);

        const statusCode =
            typeof error === "object" &&
            error !== null &&
            "statusCode" in error &&
            typeof error.statusCode === "number"
                ? error.statusCode
                : 500;

        const message =
            typeof error === "object" &&
            error !== null &&
            "message" in error &&
            typeof error.message === "string"
                ? error.message
                : "Internal server error";

        return reply.status(statusCode).send({
            status: "error",
            message,
        });
    });

    return app;
}