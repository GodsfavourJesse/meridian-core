import { buildApp } from "./app";
import { env } from "./config/env";

const app = buildApp();

const start = async () => {
    try {
        await app.listen({
            port: env.PORT,
            host: "0.0.0.0",
        });

        app.log.info(`🚀 Miyor API running on ${env.API_URL}`);
    } catch (error) {
        app.log.error(error);
        process.exit(1);
    }
};

start();