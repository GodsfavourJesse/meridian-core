import type { FastifyInstance, FastifyReply } from "fastify";
import { eq } from "drizzle-orm";

import { env } from "../config/env";
import { db } from "../database";
import { users } from "../database/schema";

import { hashPassword, verifyPassword } from "./password";
import { loginSchema, normalizeEmail, signupSchema } from "./validation";
import { createSession, getSession, revokeSession } from "./sessions";

const SESSION_COOKIE = "miyor_session";
const SESSION_MAX_AGE = 60 * 60 * 24 * 30;

function setSessionCookie(reply: FastifyReply, token: string) {
    reply.setCookie(SESSION_COOKIE, token, {
        httpOnly: true,
        secure: env.NODE_ENV === "production",
        sameSite: "lax",
        path: "/",
        maxAge: SESSION_MAX_AGE,
    });
}

function clearSessionCookie(reply: FastifyReply) {
    reply.clearCookie(SESSION_COOKIE, {
        httpOnly: true,
        secure: env.NODE_ENV === "production",
        sameSite: "lax",
        path: "/",
    });
}

function validationError(error: {
    issues: Array<{
        path: PropertyKey[];
        message: string;
    }>;
}) {
    return {
        status: "error",
        message: "Invalid request",
        errors: error.issues.map((issue) => ({
            field: issue.path.join("."),
            message: issue.message,
        })),
    };
}

export async function authRoutes(app: FastifyInstance) {
    app.post("/auth/signup", async (request, reply) => {
        const parsed = signupSchema.safeParse(request.body);

        if (!parsed.success) {
            return reply.status(400).send(
                validationError(parsed.error),
            );
        }

        const name = parsed.data.name.trim();
        const email = normalizeEmail(parsed.data.email);
        const passwordHash = await hashPassword(parsed.data.password);

        try {
            const [user] = await db
                .insert(users)
                .values({
                    name,
                    email,
                    passwordHash,
                })
                .returning({
                    id: users.id,
                    name: users.name,
                    email: users.email,
                    emailVerifiedAt: users.emailVerifiedAt,
                    status: users.status,
                    createdAt: users.createdAt,
                });

            if (!user) {
                throw new Error("Failed to create user");
            }

            const session = await createSession(user.id);

            setSessionCookie(reply, session.token);

            return reply.status(201).send({
                status: "ok",
                user,
            });
        } catch (error) {
            if (
                typeof error === "object" &&
                error !== null &&
                "code" in error &&
                error.code === "23505"
            ) {
                return reply.status(409).send({
                    status: "error",
                    message: "Email is already in use",
                });
            }

            throw error;
        }
    });

    app.post("/auth/login", async (request, reply) => {
        const parsed = loginSchema.safeParse(request.body);

        if (!parsed.success) {
            return reply.status(400).send(
                validationError(parsed.error),
            );
        }

        const email = normalizeEmail(parsed.data.email);

        const [user] = await db
            .select({
                id: users.id,
                name: users.name,
                email: users.email,
                passwordHash: users.passwordHash,
                emailVerifiedAt: users.emailVerifiedAt,
                status: users.status,
                createdAt: users.createdAt,
            })
            .from(users)
            .where(eq(users.email, email))
            .limit(1);

        if (!user) {
            return reply.status(401).send({
                status: "error",
                message: "Invalid email or password",
            });
        }

        const passwordValid = await verifyPassword(
            user.passwordHash,
            parsed.data.password,
        );

        if (!passwordValid) {
            return reply.status(401).send({
                status: "error",
                message: "Invalid email or password",
            });
        }

        if (user.status !== "active") {
            return reply.status(403).send({
                status: "error",
                message: "Account is not active",
            });
        }

        const session = await createSession(user.id);

        setSessionCookie(reply, session.token);

        return {
            status: "ok",
            user: {
                id: user.id,
                name: user.name,
                email: user.email,
                emailVerifiedAt: user.emailVerifiedAt,
                status: user.status,
                createdAt: user.createdAt,
            },
        };
    });

    app.post("/auth/logout", async (request, reply) => {
        const token = request.cookies[SESSION_COOKIE];

        if (token) {
            await revokeSession(token);
        }

        clearSessionCookie(reply);

        return {
            status: "ok",
        };
    });

    app.get("/auth/me", async (request, reply) => {
        const token = request.cookies[SESSION_COOKIE];

        if (!token) {
            return reply.status(401).send({
                status: "error",
                message: "Not authenticated",
            });
        }

        const session = await getSession(token);

        if (!session) {
            clearSessionCookie(reply);

            return reply.status(401).send({
                status: "error",
                message: "Not authenticated",
            });
        }

        const [user] = await db
            .select({
                id: users.id,
                name: users.name,
                email: users.email,
                emailVerifiedAt: users.emailVerifiedAt,
                status: users.status,
                createdAt: users.createdAt,
            })
            .from(users)
            .where(eq(users.id, session.userId))
            .limit(1);

        if (!user || user.status !== "active") {
            clearSessionCookie(reply);

            return reply.status(401).send({
                status: "error",
                message: "Not authenticated",
            });
        }

        return {
            status: "ok",
            user,
        };
    });
}
