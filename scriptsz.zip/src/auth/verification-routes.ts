import type { FastifyInstance } from "fastify";

import {
    eq,
} from "drizzle-orm";

import { db } from "../database";
import { users } from "../database/schema";
import {
    createEmailVerificationTokenForUser,
    verifyEmailToken,
} from "./email-verification";
import { sendVerificationEmail } from "./email";

export async function verificationRoutes(
    app: FastifyInstance,
) {
    app.post<{
        Body: {
            token?: string;
        };
    }>("/auth/verify-email", async (request, reply) => {
        const token =
            typeof request.body?.token === "string"
                ? request.body.token.trim()
                : "";

        if (!token) {
            return reply.status(400).send({
                status: "error",
                message: "Verification token is required",
            });
        }

        const result =
            await verifyEmailToken(token);

        if (!result) {
            return reply.status(400).send({
                status: "error",
                message:
                    "This verification link is invalid or has expired",
            });
        }

        return {
            status: "ok",
            message: "Email verified successfully",
        };
    });

    app.post<{
        Body: {
            email?: string;
        };
    }>("/auth/resend-verification", async (
        request,
        reply,
    ) => {
        const email =
            typeof request.body?.email === "string"
                ? request.body.email
                      .trim()
                      .toLowerCase()
                : "";

        if (!email) {
            return reply.status(400).send({
                status: "error",
                message: "Email is required",
            });
        }

        const [user] = await db
            .select({
                id: users.id,
                name: users.name,
                email: users.email,
                emailVerifiedAt:
                    users.emailVerifiedAt,
                status: users.status,
            })
            .from(users)
            .where(eq(users.email, email))
            .limit(1);

        /*
         * Do not reveal whether an email belongs
         * to an account.
         */
        if (
            !user ||
            user.status !== "active" ||
            user.emailVerifiedAt
        ) {
            return {
                status: "ok",
                message:
                    "If the account requires verification, a new email will be sent",
            };
        }

        try {
            const {
                token,
            } =
                await createEmailVerificationTokenForUser(
                    user.id,
                );

            await sendVerificationEmail({
                email: user.email,
                name: user.name,
                token,
            });
        } catch (error) {
            if (
                error instanceof Error &&
                error.message ===
                    "VERIFICATION_RESEND_COOLDOWN"
            ) {
                return reply.status(429).send({
                    status: "error",
                    message:
                        "Please wait before requesting another verification email",
                });
            }

            if (
                error instanceof Error &&
                error.message ===
                    "VERIFICATION_DAILY_LIMIT"
            ) {
                return reply.status(429).send({
                    status: "error",
                    message:
                        "Verification email limit reached. Please try again later",
                });
            }

            throw error;
        }

        return {
            status: "ok",
            message:
                "If the account requires verification, a new email will be sent",
        };
    });
}